<?php
// navbar.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<nav class="navbar">
    <a href="index.php" class="navbar-brand">TechStore</a>
    <ul class="navbar-nav">
        <li><a href="index.php">Accueil</a></li>
        <li><a href="products.php">Produits</a></li>
        
        <?php if (isset($_SESSION['user_id'])): ?>
            <li><a href="profile.php">Mon Profil</a></li>
            <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                <li><a href="admin/index.php">Back-Office</a></li>
            <?php endif; ?>
            <li><a href="logout.php">Déconnexion (<?= htmlspecialchars($_SESSION['username']) ?>)</a></li>
        <?php else: ?>
            <li><a href="login.php">Connexion</a></li>
            <li><a href="register.php">Inscription</a></li>
        <?php endif; ?>
    </ul>
</nav>
