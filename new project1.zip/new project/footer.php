<?php
// footer.php
?>
    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-white-50 footer pt-5 mt-5">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-lg-6 col-md-6">
                    <h4 class="text-white mb-4">TechStore</h4>
                    <p>Votre boutique spécialisée dans la vente de téléphones et accessoires de haute qualité.</p>
                </div>
                <div class="col-lg-6 col-md-6">
                    <h4 class="text-white mb-4">Contactez-nous</h4>
                    <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>Route Al Ain km 3,5</p>
                    <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+216 28 953 394</p>
                    <p class="mb-2"><i class="fa fa-envelope me-3"></i>contact@techstore.com</p>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->

    <!-- Copyright Start -->
    <div class="container-fluid copyright py-4 bg-dark">
        <div class="container">
            <div class="row g-4 align-items-center">
                <div class="col-md-6 text-center text-md-start mb-md-0">
                    <span class="text-white"><i class="fas fa-copyright text-light me-2"></i>TechStore, All right reserved.</span>
                </div>
                <div class="col-md-6 text-center text-md-end text-white">
                    Designed By HTML Codex
                </div>
            </div>
        </div>
    </div>
    <!-- Copyright End -->

    <!-- JavaScript Libraries -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
