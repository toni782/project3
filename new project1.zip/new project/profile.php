<?php
// profile.php
require 'config.php';
check_login();

$error = '';
$success = '';

// Fetch current user data
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (!empty($username) && !empty($email)) {
        // Check if email already used by someone else
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $stmt->execute([$email, $_SESSION['user_id']]);
        
        if ($stmt->fetch()) {
            $error = "Cet email est déjà utilisé par un autre compte.";
        } else {
            if (!empty($password)) {
                // Update with password
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, password = ? WHERE id = ?");
                $result = $stmt->execute([$username, $email, $hashed_password, $_SESSION['user_id']]);
            } else {
                // Update without password
                $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ? WHERE id = ?");
                $result = $stmt->execute([$username, $email, $_SESSION['user_id']]);
            }

            if ($result) {
                $_SESSION['username'] = $username; // Update session
                $success = "Vos informations ont été mises à jour avec succès.";
                // Refresh user data
                $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
                $stmt->execute([$_SESSION['user_id']]);
                $user = $stmt->fetch();
            } else {
                $error = "Une erreur est survenue lors de la mise à jour.";
            }
        }
    } else {
        $error = "Le nom d'utilisateur et l'email sont obligatoires.";
    }
}

include 'header.php';
?>

<!-- Page Header -->
<div class="container-fluid page-header py-5 mb-5 bg-dark">
    <div class="container py-5 text-center">
        <h1 class="display-4 text-white mb-3">Mon Profil</h1>
    </div>
</div>

<div class="container-xxl py-5">
    <div class="container">
        <div class="row g-5">
            
            <div class="col-lg-5">
                <div class="bg-light p-5 rounded h-100">
                    <h3 class="mb-4">Modifier mes informations</h3>
                    
                    <?php if ($error): ?>
                        <div class="alert-error"><?= htmlspecialchars($error) ?></div>
                    <?php endif; ?>
                    <?php if ($success): ?>
                        <div class="alert-success"><?= htmlspecialchars($success) ?></div>
                    <?php endif; ?>

                    <form method="POST">
                        <div class="mb-3">
                            <label for="username" class="form-label">Nom d'utilisateur</label>
                            <input type="text" class="form-control" id="username" name="username" value="<?= htmlspecialchars($user['username']) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Adresse Email</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
                        </div>
                        <div class="mb-4">
                            <label for="password" class="form-label">Nouveau mot de passe <small class="text-muted">(Laissez vide pour ne pas modifier)</small></label>
                            <input type="password" class="form-control" id="password" name="password">
                        </div>
                        <button type="submit" class="btn btn-primary py-3 px-5 rounded-pill w-100">Mettre à jour</button>
                    </form>
                </div>
            </div>

            <div class="col-lg-7">
                <div class="bg-white border rounded p-5 h-100 shadow-sm">
                    <h3 class="mb-4">Historique de mes commandes</h3>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>Date</th>
                                    <th>Image</th>
                                    <th>Produit</th>
                                    <th>Quantité</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $stmt = $pdo->prepare("
                                    SELECT o.*, p.name, p.image 
                                    FROM orders o 
                                    JOIN products p ON o.product_id = p.id 
                                    WHERE o.user_id = ? 
                                    ORDER BY o.order_date DESC
                                ");
                                $stmt->execute([$_SESSION['user_id']]);
                                $hasOrders = false;
                                while ($order = $stmt->fetch()):
                                    $hasOrders = true;
                                ?>
                                <tr>
                                    <td><?= date('d/m/Y H:i', strtotime($order['order_date'])) ?></td>
                                    <td>
                                        <img src="img/<?= htmlspecialchars($order['image']) ?>" alt="" style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px;">
                                    </td>
                                    <td class="fw-bold text-primary"><?= htmlspecialchars($order['name']) ?></td>
                                    <td><?= $order['quantity'] ?></td>
                                </tr>
                                <?php endwhile; 
                                if (!$hasOrders):
                                ?>
                                <tr>
                                    <td colspan="4" class="text-center py-4 text-muted">Vous n'avez passé aucune commande pour le moment.</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
