<?php
// header.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>TechStore - Smartphones et Accessoires</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    
    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600;700&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet"> 

    <!-- Icon Font Stylesheet -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    
    <!-- Optional custom styles for our small forms -->
    <style>
        .form-container { max-width: 500px; margin: 3rem auto; background: #fff; padding: 2rem; border-radius: 8px; box-shadow: 0 0 15px rgba(0,0,0,0.1); }
        .alert-error { color: #dc3545; background-color: #f8d7da; padding: 1rem; border-radius: 5px; margin-bottom: 1rem; border: 1px solid #f5c2c7; text-align: center; }
        .alert-success { color: #0f5132; background-color: #d1e7dd; padding: 1rem; border-radius: 5px; margin-bottom: 1rem; border: 1px solid #badbcc; text-align: center; }
    </style>
</head>
<body>
    <!-- Topbar Start -->
    <div class="container-fluid px-5 d-none border-bottom d-lg-block">
        <div class="row gx-0 align-items-center">
            <div class="col-lg-4 text-center text-lg-start mb-lg-0">
                <div class="d-inline-flex align-items-center" style="height: 45px;">
                    <a href="#" class="text-muted me-2"> Bienvenue sur TechStore</a>
                </div>
            </div>
            <div class="col-lg-4 text-center text-lg-end offset-lg-4">
                <div class="d-inline-flex align-items-center" style="height: 45px;">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <span class="text-muted me-2">Bonjour, <?= htmlspecialchars($_SESSION['username']) ?></span><small> / </small>
                        <a href="profile.php" class="text-muted mx-2">Mon Profil</a><small> / </small>
                        <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                            <a href="admin/index.php" class="text-muted mx-2">Back-Office</a><small> / </small>
                        <?php endif; ?>
                        <a href="logout.php" class="text-muted ms-2">Déconnexion</a>
                    <?php else: ?>
                        <a href="login.php" class="text-muted me-2">Connexion</a><small> / </small>
                        <a href="register.php" class="text-muted ms-2">Inscription</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <!-- Topbar End -->

    <!-- Navbar Start -->
    <div class="container-fluid nav-bar p-0">
        <div class="row gx-0 bg-primary px-5 align-items-center">
            <div class="col-12">
                <nav class="navbar navbar-expand-lg navbar-light bg-primary py-3">
                    <a href="index.php" class="navbar-brand">
                        <h1 class="display-5 text-secondary m-0"><i class="fas fa-mobile-alt text-white me-2"></i>TechStore</h1>
                    </a>
                    <button class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                        <span class="fa fa-bars fa-1x text-white"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarCollapse">
                        <div class="navbar-nav ms-auto py-0">
                            <a href="index.php" class="nav-item nav-link <?php if(basename($_SERVER['PHP_SELF']) == 'index.php') echo 'active'; ?>">Accueil</a>
                            <a href="products.php" class="nav-item nav-link <?php if(basename($_SERVER['PHP_SELF']) == 'products.php') echo 'active'; ?>">Nos Produits</a>
                            <?php if (isset($_SESSION['user_id'])): ?>
                            <a href="profile.php" class="nav-item nav-link <?php if(basename($_SERVER['PHP_SELF']) == 'profile.php') echo 'active'; ?>">Mon Profil</a>
                            <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                                <a href="admin/index.php" class="nav-item nav-link">Back-Office</a>
                            <?php endif; ?>
                            <a href="logout.php" class="nav-item nav-link text-danger">Déconnexion</a>
                            <?php else: ?>
                            <a href="login.php" class="nav-item nav-link d-lg-none">Connexion</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </div>
    <!-- Navbar End -->
