<?php
// order.php
require 'config.php';
check_login();

$error = '';
$success = '';
$product = null;

if (isset($_GET['id'])) {
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    $product = $stmt->fetch();
}

if (!$product) {
    header("Location: products.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $quantity = (int)$_POST['quantity'];
    
    if ($quantity > 0) {
        $stmt = $pdo->prepare("INSERT INTO orders (user_id, product_id, quantity) VALUES (?, ?, ?)");
        if ($stmt->execute([$_SESSION['user_id'], $product['id'], $quantity])) {
            $success = "Votre commande a été passée avec succès !";
        } else {
            $error = "Une erreur est survenue lors de la commande.";
        }
    } else {
        $error = "Veuillez entrer une quantité valide.";
    }
}

include 'header.php';
?>

<!-- Page Header -->
<div class="container-fluid page-header py-5 mb-5 bg-dark">
    <div class="container py-5 text-center">
        <h1 class="display-4 text-white mb-3">Commander</h1>
    </div>
</div>

<div class="container-xxl py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="bg-white p-5 rounded shadow-sm border">
                    <h2 class="mb-4">Confirmer votre achat</h2>
                    
                    <?php if ($error): ?>
                        <div class="alert-error"><?= htmlspecialchars($error) ?></div>
                    <?php endif; ?>
                    <?php if ($success): ?>
                        <div class="alert-success"><?= htmlspecialchars($success) ?></div>
                    <?php endif; ?>

                    <div class="row mb-5 align-items-center">
                        <div class="col-md-5">
                            <img src="img/<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="img-fluid rounded border">
                        </div>
                        <div class="col-md-7">
                            <h3><?= htmlspecialchars($product['name']) ?></h3>
                            <p class="text-muted mt-3"><?= nl2br(htmlspecialchars($product['description'])) ?></p>
                            <h4 class="text-primary mt-3"><?= number_format($product['price'], 2) ?> € / unité</h4>
                        </div>
                    </div>

                    <?php if (!$success): ?>
                    <form method="POST">
                        <div class="mb-4">
                            <label for="quantity" class="form-label fw-bold">Quantité souhaitée</label>
                            <input type="number" class="form-control" id="quantity" name="quantity" min="1" value="1" required style="max-width: 200px;">
                        </div>
                        <button type="submit" class="btn btn-primary py-3 px-5 rounded-pill">Confirmer la commande</button>
                    </form>
                    <?php else: ?>
                        <a href="products.php" class="btn btn-outline-primary py-3 px-5 rounded-pill mt-3">Retour aux produits</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
