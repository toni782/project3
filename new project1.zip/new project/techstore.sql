-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mer. 13 mai 2026 à 10:16
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `techstore`
--

-- --------------------------------------------------------

--
-- Structure de la table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT 1,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `product_id`, `quantity`, `order_date`) VALUES
(1, 2, 5, 2, '2026-04-25 08:52:08');

-- --------------------------------------------------------

--
-- Structure de la table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `image` varchar(255) DEFAULT 'default.png',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `image`, `created_at`) VALUES
(1, 'iPhone 15 Pro max', 'Double SIM - Écran Super Retina XDR 6.1\" - Résolution de 2556 x 1179 pixels - Puce A17 Pro avec GPU 6 cœurs (CPU 6 cœurs, GPU 6 cœurs, Neural Engine 16 cœurs) - RAM 8 Go - Stockage 128 Go - Appareil photo: (Objectif principal 48 Mpx 24 mm, ouverture ƒ/1.78 / Ultra grand-angle 12 Mpx 13 mm, ouverture ƒ/2.2 / Téléobjectif 2x 12 Mpx 48 mm, ouverture ƒ/1.78 / Téléobjectif 3x 12 Mpx : 77 mm, ouverture ƒ/2.8 / Zoom numérique jusqu’à 15x) - Flash True Tone adaptatif - Smart HDR 5 - Caméra TrueDepth (Selfie): 12 Mpx', 1199.99, 'Open-Box-Apple-iPhone-15-Pro-Max-A2849-256GB-Natural-Titanium-US-Model-Factory-Unlocked-Cell-Phone_429653c4-c06f-4cd5-bbb1-731395d25f06.c19faec285b44b42a97365a3b9e91b75.avif', '2026-04-24 22:44:46'),
(2, 'AirPods Pro 2', 'Écouteurs sans fil avec réduction de bruit active et Audio Spatial.', 279.00, 'hearingairpods.jpeg', '2026-04-24 22:44:46'),
(3, 'Chargeur Rapide 20W', 'Adaptateur secteur USB-C 20W pour une charge rapide et efficace.', 25.00, 'chargeur-itel-icw-201e-.jpg', '2026-04-24 22:44:46'),
(4, 'Coque en Silicone', 'Coque de protection en silicone doux au toucher avec MagSafe.', 45.00, 'coque-de-protection-silicone-iphone-14-pro-max-bleu-marine.jpg', '2026-04-24 22:44:46'),
(5, 'samsung s26 ultra', 'Samsung  S26 Ultra - Ecran : 6,9\" QHD+ Dynamic AMOLED 2X (3120 x 1440 pixel), 120Hz,  Cadre en aluminium Armor/ Corning Gorilla Armor 2 / Corning  Gorilla Glass Victus  2 - Processeur : Snapdragon® 8 Elite Gen 5 pour Galaxy - Système d’exploitation : Android 16, One UI 8.5 - Mémoire : 12Go - Stockage : 512Go - Appareil photo arrière : Grand Angle 200 Mpx, Ultra Grand Angle 50 Mpx, Téléobjectif 50 Mpx / 10 Mpx - Avant : 12 Mpx', 1199.99, 'download.jpg', '2026-04-25 08:50:06');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','user') DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `created_at`) VALUES
(1, 'admin', 'admin@techstore.com', '$2y$10$Fc3XFRDOul3/DvXvbXfKRO/mngsTFq6iTN5cdiSUglZsR/pL4mrEi', 'admin', '2026-04-24 22:44:46'),
(2, 'houssem', 'houssemgho782@gmail.com', '$2y$10$GGC5xkq6ldNFZQYbtyRPPOVgDnpbOGT3iwX0A2vFLhAGC7L5pKP1i', 'user', '2026-04-24 22:46:38');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Index pour la table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
