CREATE DATABASE IF NOT EXISTS techstore;
USE techstore;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'user') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    image VARCHAR(255) DEFAULT 'default.png',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT DEFAULT 1,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- Insert admin account (password: admin123)
INSERT INTO users (username, email, password, role) 
VALUES ('admin', 'admin@techstore.com', '$2y$10$SULy4j0tUt8K8/yi1xOjVuuTT7GrbU2IF2olBfCSHcyerwKde.dFu', 'admin');

-- Insert some dummy products
INSERT INTO products (name, description, price, image) VALUES 
('iPhone 15 Pro', 'Le dernier iPhone avec puce A17 Pro et appareil photo 48 Mpx.', 1199.99, 'iphone15pro.png'),
('AirPods Pro 2', 'Écouteurs sans fil avec réduction de bruit active et Audio Spatial.', 279.00, 'airpods.png'),
('Chargeur Rapide 20W', 'Adaptateur secteur USB-C 20W pour une charge rapide et efficace.', 25.00, 'charger.png'),
('Coque en Silicone', 'Coque de protection en silicone doux au toucher avec MagSafe.', 45.00, 'case.png');
