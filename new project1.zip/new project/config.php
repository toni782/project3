<?php
// config.php
$host = 'localhost';
$db_name = 'techstore';
$username = 'root'; // default XAMPP user
$password = ''; // default XAMPP password is empty

try {
    $pdo = new PDO("mysql:host=$host", $username, $password);
    
    // Create DB if it doesn't exist
    $pdo->exec("CREATE DATABASE IF NOT EXISTS $db_name");
    $pdo->exec("USE $db_name");
    
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Helper function to check if user is logged in
function check_login() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php");
        exit;
    }
}

// Helper function to check if user is admin
function check_admin() {
    check_login();
    if ($_SESSION['role'] !== 'admin') {
        header("Location: index.php");
        exit;
    }
}
?>
