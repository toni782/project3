<?php
// index.php
require 'config.php';
check_login();
include 'header.php';
?>

<!-- Hero Section -->
<div class="container-fluid bg-light py-5 mb-5 hero-header">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-8 text-center">
                <h1 class="display-3 mb-4">Découvrez notre sélection de smartphones et d'accessoires</h1>
                <p class="fs-5 mb-5">Retrouvez les meilleurs chargeurs, AirPods et coques au meilleur prix.</p>
                <a href="products.php" class="btn btn-primary py-3 px-5 rounded-pill">Voir nos produits</a>
            </div>
        </div>
    </div>
</div>

<!-- Products Section -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="text-center mx-auto mb-5" style="max-width: 600px;">
            <h1 class="display-5 mb-4">Notre Sélection</h1>
        </div>
        <div class="row g-4">
            <?php
            $stmt = $pdo->query("SELECT * FROM products ORDER BY created_at DESC LIMIT 3");
            while ($product = $stmt->fetch()):
            ?>
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="product-item rounded border shadow-sm h-100 bg-white">
                    <div class="position-relative overflow-hidden" style="height: 250px;">
                        <img class="img-fluid w-100 h-100 object-cover" src="img/<?= htmlspecialchars($product['image']) ?>" alt="" style="object-fit: cover;">
                    </div>
                    <div class="p-4 text-center">
                        <h4 class="mb-3"><?= htmlspecialchars($product['name']) ?></h4>
                        <p class="text-muted"><?= htmlspecialchars(substr($product['description'], 0, 80)) ?>...</p>
                        <h5 class="text-primary mb-3"><?= number_format($product['price'], 2) ?> €</h5>
                        <a href="order.php?id=<?= $product['id'] ?>" class="btn btn-outline-primary rounded-pill px-4">Commander</a>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
