```mermaid
classDiagram
    class User {
        +int id
        +string username
        +string email
        +string password
        +string role
        +timestamp created_at
        +register()
        +login()
        +updateProfile()
    }

    class Product {
        +int id
        +string name
        +string description
        +float price
        +string image
        +timestamp created_at
    }

    class Order {
        +int id
        +int user_id
        +int product_id
        +int quantity
        +timestamp order_date
    }

    class Admin {
        +addProduct(Product p)
        +editProduct(Product p)
        +deleteProduct(int id)
    }

    User "1" -- "*" Order : places
    Product "1" -- "*" Order : belongs to
    User <|-- Admin : inherits
```
