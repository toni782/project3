<?php
// admin/header.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Administration - TechStore</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    
    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600;700&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet"> 

    <!-- Icon Font Stylesheet -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="../css/style.css" rel="stylesheet">
    
    <style>
        .alert-error { color: #dc3545; background-color: #f8d7da; padding: 1rem; border-radius: 5px; margin-bottom: 1rem; border: 1px solid #f5c2c7; }
        .alert-success { color: #0f5132; background-color: #d1e7dd; padding: 1rem; border-radius: 5px; margin-bottom: 1rem; border: 1px solid #badbcc; }
    </style>
</head>
<body>
    <!-- Navbar Start -->
    <div class="container-fluid nav-bar p-0">
        <div class="row gx-0 bg-dark px-5 align-items-center">
            <div class="col-12">
                <nav class="navbar navbar-expand-lg navbar-dark bg-dark py-3">
                    <a href="index.php" class="navbar-brand">
                        <h1 class="display-6 text-white m-0"><i class="fas fa-cog text-primary me-2"></i>Admin Panel</h1>
                    </a>
                    <button class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                        <span class="fa fa-bars fa-1x text-white"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarCollapse">
                        <div class="navbar-nav ms-auto py-0">
                            <a href="index.php" class="nav-item nav-link <?php if(basename($_SERVER['PHP_SELF']) == 'index.php') echo 'active'; ?>">Produits</a>
                            <a href="orders.php" class="nav-item nav-link <?php if(basename($_SERVER['PHP_SELF']) == 'orders.php') echo 'active'; ?>">Commandes</a>
                            <a href="../index.php" class="nav-item nav-link">Retour au site</a>
                            <a href="../logout.php" class="nav-item nav-link text-danger">Déconnexion</a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </div>
    <!-- Navbar End -->
