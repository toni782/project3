<?php
// admin/index.php
require '../config.php';
check_admin();

// Fetch products
$stmt = $pdo->query("SELECT * FROM products ORDER BY created_at DESC");
$products = $stmt->fetchAll();

include 'header.php';
?>

<div class="container-fluid page-header py-5 mb-5 bg-secondary">
    <div class="container py-5 text-center">
        <h1 class="display-5 text-white mb-3">Gestion des Produits</h1>
    </div>
</div>

<div class="container-xxl py-5">
    <div class="container">
        
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Liste des produits</h2>
            <a href="add_product.php" class="btn btn-primary rounded-pill px-4">Ajouter un produit</a>
        </div>

        <?php if (isset($_GET['msg']) && $_GET['msg'] === 'deleted'): ?>
            <div class="alert-success">Produit supprimé avec succès.</div>
        <?php endif; ?>

        <div class="bg-white border rounded shadow-sm p-4">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Image</th>
                            <th>Nom</th>
                            <th>Prix</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $p): ?>
                        <tr>
                            <td><?= $p['id'] ?></td>
                            <td>
                                <img src="../img/<?= htmlspecialchars($p['image']) ?>" alt="" style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px;">
                            </td>
                            <td class="fw-bold"><?= htmlspecialchars($p['name']) ?></td>
                            <td class="text-primary fw-bold"><?= number_format($p['price'], 2) ?> €</td>
                            <td class="text-end">
                                <a href="edit_product.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-secondary me-2"><i class="fas fa-edit"></i> Modifier</a>
                                <a href="delete_product.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce produit ?');"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<?php include 'footer.php'; ?>
