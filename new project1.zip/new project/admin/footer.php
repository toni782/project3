<?php
// admin/footer.php
?>
    <!-- Copyright Start -->
    <div class="container-fluid copyright py-4 bg-dark mt-5">
        <div class="container text-center">
            <span class="text-white">TechStore Admin Panel</span>
        </div>
    </div>
    <!-- Copyright End -->

    <!-- JavaScript Libraries -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/main.js"></script>
</body>
</html>
