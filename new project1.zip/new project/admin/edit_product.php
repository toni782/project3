<?php
// admin/edit_product.php
require '../config.php';
check_admin();

$error = '';
$success = '';

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$id = (int)$_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch();

if (!$product) {
    header("Location: index.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $price = (float)$_POST['price'];
    $image = trim($_POST['image_name']);

    // File upload handling
    if (isset($_FILES['image_file']) && $_FILES['image_file']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../img/';
        $fileName = basename($_FILES['image_file']['name']);
        $targetFilePath = $uploadDir . $fileName;
        
        // Move the file
        if (move_uploaded_file($_FILES['image_file']['tmp_name'], $targetFilePath)) {
            $image = $fileName;
        } else {
            $error = "Erreur lors du téléchargement de l'image.";
        }
    }

    if (!empty($name) && $price > 0) {
        $stmt = $pdo->prepare("UPDATE products SET name = ?, description = ?, price = ?, image = ? WHERE id = ?");
        if ($stmt->execute([$name, $description, $price, $image, $id])) {
            $success = "Produit mis à jour avec succès.";
            // Refresh product data
            $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
            $stmt->execute([$id]);
            $product = $stmt->fetch();
        } else {
            $error = "Erreur lors de la mise à jour.";
        }
    } else {
        $error = "Veuillez remplir correctement les champs obligatoires.";
    }
}

include 'header.php';
?>

<div class="container-xxl py-5">
    <div class="container">
        
        <div class="mb-4">
            <a href="index.php" class="btn btn-outline-secondary rounded-pill"><i class="fas fa-arrow-left"></i> Retour au Dashboard</a>
        </div>

        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="bg-white border rounded shadow-sm p-5">
                    <h3 class="mb-4">Modifier : <?= htmlspecialchars($product['name']) ?></h3>
                    
                    <?php if ($error): ?>
                        <div class="alert-error"><?= htmlspecialchars($error) ?></div>
                    <?php endif; ?>
                    <?php if ($success): ?>
                        <div class="alert-success"><?= htmlspecialchars($success) ?></div>
                    <?php endif; ?>

                    <form method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="name" class="form-label fw-bold">Nom du produit *</label>
                            <input type="text" class="form-control" id="name" name="name" value="<?= htmlspecialchars($product['name']) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="price" class="form-label fw-bold">Prix (€) *</label>
                            <input type="number" step="0.01" class="form-control" id="price" name="price" value="<?= $product['price'] ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label fw-bold">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="5"><?= htmlspecialchars($product['description']) ?></textarea>
                        </div>
                        <div class="mb-4">
                            <label for="image_file" class="form-label fw-bold">Modifier l'image</label>
                            <input class="form-control" type="file" id="image_file" name="image_file" accept="image/*">
                            <div class="form-text">Envoyer une nouvelle image depuis votre ordinateur.</div>
                        </div>
                        <div class="mb-4">
                            <label for="image_name" class="form-label fw-bold">OU Nom du fichier image actuel</label>
                            <input type="text" class="form-control" id="image_name" name="image_name" value="<?= htmlspecialchars($product['image']) ?>">
                            <div class="form-text">Si vous n'envoyez pas de fichier, l'image actuelle (ou le nom spécifié ici) sera conservée.</div>
                        </div>
                        <button type="submit" class="btn btn-primary py-3 px-5 rounded-pill w-100">Mettre à jour</button>
                    </form>
                </div>
            </div>
        </div>

    </div>
</div>

<?php include 'footer.php'; ?>
