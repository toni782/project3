<?php
// admin/orders.php
require '../config.php';
check_admin();

// Fetch all orders with user and product details
$stmt = $pdo->query("
    SELECT o.*, u.username, u.email, p.name AS product_name, p.image 
    FROM orders o
    JOIN users u ON o.user_id = u.id
    JOIN products p ON o.product_id = p.id
    ORDER BY o.order_date DESC
");
$orders = $stmt->fetchAll();

include 'header.php';
?>

<div class="container-fluid page-header py-5 mb-5 bg-secondary">
    <div class="container py-5 text-center">
        <h1 class="display-5 text-white mb-3">Toutes les Commandes</h1>
    </div>
</div>

<div class="container-xxl py-5">
    <div class="container">
        
        <div class="mb-4">
            <h2>Historique global des achats</h2>
        </div>

        <div class="bg-white border rounded shadow-sm p-4">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Date</th>
                            <th>Client (Email)</th>
                            <th>Image</th>
                            <th>Produit</th>
                            <th>Quantité</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($orders) > 0): ?>
                            <?php foreach ($orders as $o): ?>
                            <tr>
                                <td><?= date('d/m/Y H:i', strtotime($o['order_date'])) ?></td>
                                <td>
                                    <span class="fw-bold"><?= htmlspecialchars($o['username']) ?></span><br>
                                    <small class="text-muted"><?= htmlspecialchars($o['email']) ?></small>
                                </td>
                                <td>
                                    <img src="../img/<?= htmlspecialchars($o['image']) ?>" alt="" style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px;">
                                </td>
                                <td class="fw-bold text-primary"><?= htmlspecialchars($o['product_name']) ?></td>
                                <td><?= $o['quantity'] ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center py-4 text-muted">Aucune commande n'a été passée sur le site.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<?php include 'footer.php'; ?>
