<?php
// admin/add_product.php
require '../config.php';
check_admin();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $price = (float)$_POST['price'];
    $image = 'default.png';

    // Basic file upload handling for simplicity, normally we move_uploaded_file
    if (!empty($_POST['image_name'])) {
        $image = trim($_POST['image_name']);
    }

    if (!empty($name) && $price > 0) {
        $stmt = $pdo->prepare("INSERT INTO products (name, description, price, image) VALUES (?, ?, ?, ?)");
        if ($stmt->execute([$name, $description, $price, $image])) {
            $success = "Produit ajouté avec succès.";
        } else {
            $error = "Erreur lors de l'ajout.";
        }
    } else {
        $error = "Veuillez remplir correctement les champs obligatoires.";
    }
}

include 'header.php';
?>

<div class="container-xxl py-5">
    <div class="container">
        
        <div class="mb-4">
            <a href="index.php" class="btn btn-outline-secondary rounded-pill"><i class="fas fa-arrow-left"></i> Retour au Dashboard</a>
        </div>

        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="bg-white border rounded shadow-sm p-5">
                    <h3 class="mb-4">Ajouter un Nouveau Produit</h3>
                    
                    <?php if ($error): ?>
                        <div class="alert-error"><?= htmlspecialchars($error) ?></div>
                    <?php endif; ?>
                    <?php if ($success): ?>
                        <div class="alert-success"><?= htmlspecialchars($success) ?></div>
                    <?php endif; ?>

                    <form method="POST">
                        <div class="mb-3">
                            <label for="name" class="form-label fw-bold">Nom du produit *</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label for="price" class="form-label fw-bold">Prix (€) *</label>
                            <input type="number" step="0.01" class="form-control" id="price" name="price" required>
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label fw-bold">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="5"></textarea>
                        </div>
                        <div class="mb-4">
                            <label for="image_name" class="form-label fw-bold">Nom du fichier image (ex: laptop.png)</label>
                            <input type="text" class="form-control" id="image_name" name="image_name" value="default.png">
                            <div class="form-text">L'image doit être placée dans le dossier img/</div>
                        </div>
                        <button type="submit" class="btn btn-primary py-3 px-5 rounded-pill w-100">Enregistrer</button>
                    </form>
                </div>
            </div>
        </div>

    </div>
</div>

<?php include 'footer.php'; ?>
