<?php
// products.php
require 'config.php';
check_login();
include 'header.php';
?>

<!-- Page Header -->
<div class="container-fluid page-header py-5 mb-5 bg-dark">
    <div class="container py-5 text-center">
        <h1 class="display-4 text-white mb-3">Tous Nos Produits</h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb justify-content-center mb-0">
                <li class="breadcrumb-item"><a href="index.php" class="text-white">Accueil</a></li>
                <li class="breadcrumb-item active text-primary" aria-current="page">Produits</li>
            </ol>
        </nav>
    </div>
</div>

<!-- Products Section -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="row g-4">
            <?php
            $stmt = $pdo->query("SELECT * FROM products ORDER BY name ASC");
            while ($product = $stmt->fetch()):
            ?>
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="product-item rounded border shadow-sm h-100 bg-white">
                    <div class="position-relative overflow-hidden" style="height: 250px;">
                        <img class="img-fluid w-100 h-100 object-cover" src="img/<?= htmlspecialchars($product['image']) ?>" alt="" style="object-fit: cover;">
                    </div>
                    <div class="p-4 text-center">
                        <h4 class="mb-3"><?= htmlspecialchars($product['name']) ?></h4>
                        <p class="text-muted"><?= nl2br(htmlspecialchars($product['description'])) ?></p>
                        <h5 class="text-primary mb-3"><?= number_format($product['price'], 2) ?> €</h5>
                        <a href="order.php?id=<?= $product['id'] ?>" class="btn btn-outline-primary rounded-pill px-4">Commander</a>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
